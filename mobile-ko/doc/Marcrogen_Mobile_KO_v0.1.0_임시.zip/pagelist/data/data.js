const data = {}
data.main = {
  title: 'Main',
  list: [
    {
      stateClass: 'working',
      url: 'Intro',
      category: 'main',
      page: 'Intro'
    }
  ]
}
